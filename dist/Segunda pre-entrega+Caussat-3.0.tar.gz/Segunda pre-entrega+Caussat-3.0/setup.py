from setuptools import setup, find_packages

setup(
    name='Segunda pre-entrega+Caussat',
    version='3.0',
    description='Tienda Hypebeast',
    author='Kevin Caussat',
    author_email='kevin.csst.grego@gmail.com',
    packages=find_packages(),
    install_requires=[
    ],
)